Contexto privado de la demo (meses de origen 2024-11 a 2025-10)

Son 12 archivos contexto-AAAA-MM.csv, con 76 municipios cada uno, más su índice contexto.json, que trae la huella SHA-256 de cada archivo y el release crudo del que salen (satd-raw-173d5856).

Uso: copiar los 13 archivos a pipeline/data/demo/ dentro del repositorio y levantar la demo como dice el README:
  uv run --locked --project pipeline --with-requirements demo/requirements.txt streamlit run demo/app.py

La demo verifica las huellas al cargar, así que si algún archivo cambia, no arranca. No hace falta HF_TOKEN.
Estos archivos no se suben al repositorio: son datos de 2025 derivados del release privado.
